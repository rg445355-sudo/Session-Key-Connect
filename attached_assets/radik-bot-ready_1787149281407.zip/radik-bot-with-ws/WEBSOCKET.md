# Как подключить WebSocket Pocket Option к RADIK AI BOT

## Кратко

| Что | Где |
|-----|-----|
| Frontend (React) | `src/App.tsx` |
| Генерация сигналов (пока рандом) | `supabase/functions/radik-bot/index.ts` |
| **Реальное WebSocket-подключение по SSID** | `python-bot/bot.py` |

Supabase Edge Function **не умеет** держать долгое WebSocket-соединение и не может запускать Python-библиотеку `PocketOptionAPI-v2`.

Поэтому реальное подключение вынесено в отдельный Python-сервис.

---

## Шаг 1. Получи SSID

1. Зайди на https://pocketoption.com
2. F12 → Network → фильтр **WS**
3. Найди сообщение:
   ```
   42["auth",{"session":"...","isDemo":1,"uid":...,"platform":2}]
   ```
4. Скопируй **всю** строку.

## Шаг 2. Запусти Python-бот

```bash
cd python-bot
cp .env.example .env
# вставь SSID в .env
pip install -r requirements.txt
python bot.py
```

После успешного подключения увидишь баланс и HTTP API на порту `8765`.

## Шаг 3 (опционально). Связать с Supabase

В secrets Supabase добавь:

```
POCKET_SSID=42["auth",{...}]
PYTHON_BOT_URL=https://твой-публичный-url-python-бота
```

Тогда `GET /functions/v1/radik-bot/health` будет возвращать реальное состояние соединения.

---

## Что сейчас делает основной бот

- Генерирует сигналы **рандомно** (пара, направление, confidence 88–94 %).
- Хранит историю в таблице `bot_signals`.
- Поддерживает «перекрытие» при проигрыше.

Чтобы сигналы стали основаны на реальных ценах — нужно дописать стратегию в `python-bot` (анализ тиков/свечей) и либо:

- писать сигналы прямо в Supabase из Python,  
- либо проксировать через edge-функцию.

Готовый каркас WebSocket-подключения уже лежит в `python-bot/`.
