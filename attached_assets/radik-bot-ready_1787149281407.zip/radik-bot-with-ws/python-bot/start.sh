#!/bin/bash
set -e
cd "$(dirname "$0")"
if [ ! -f .env ]; then
  echo "Нет .env — копирую из .env.example"
  cp .env.example .env
  echo "Отредактируй .env и запусти снова"
  exit 1
fi
pip install -q -r requirements.txt
exec python bot.py
