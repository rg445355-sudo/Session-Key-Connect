# RADIK AI BOT — реальное подключение к Pocket Option WebSocket

Текущий frontend + Supabase Edge Function генерируют **сигналы локально** (рандом).  
Чтобы подключиться к **реальному** WebSocket Pocket Option по SSID, используй этот Python-сервис.

## Почему отдельно Python?

- Библиотека `PocketOptionAPI-v2` — **только Python**.
- Supabase Edge Functions работают на **Deno** и не умеют запускать Python.
- WebSocket-соединение должно быть **долгоживущим** — Edge Function живёт только на время запроса.

Поэтому правильная архитектура:

```
Browser (React)  →  Supabase Edge Function  →  (опционально) Python-bot HTTP API
                                              ↑
                                    WebSocket ↔ Pocket Option
```

## Быстрый старт

```bash
cd python-bot

# 1. Установка
pip install -r requirements.txt

# 2. Создай .env
cp .env.example .env
```

### Как получить SSID

1. Открой https://pocketoption.com и **войди** в аккаунт.
2. Нажми **F12** → вкладка **Network**.
3. Фильтр **WS** (WebSocket).
4. Обнови страницу / открой любой актив.
5. Найди сообщение, которое начинается с:

```
42["auth",{"session":"...","isDemo":1,"uid":123456,"platform":2}]
```

6. Скопируй **всю строку целиком** и вставь в `.env`:

```env
POCKET_SSID=42["auth",{"session":"ТВОЯ_СЕССИЯ","isDemo":1,"uid":ТВОЙ_UID,"platform":2}]
POCKET_DEMO=true
API_PORT=8765
```

> ⚠️ SSID живёт ограниченное время. Если перестал работать — получи новый.

### Запуск

```bash
python bot.py
```

Ты увидишь:

```
🔌 Подключение к Pocket Option WebSocket (demo=True)...
✅ Подключено! Баланс: $10000.00
🌐 HTTP API запущен на http://0.0.0.0:8765
```

## Доступные эндпоинты Python-бота

| Метод | URL | Описание |
|-------|-----|----------|
| GET | `/health` | Статус соединения + баланс |
| GET | `/balance` | Текущий баланс |
| POST | `/buy` | Открыть сделку |
| GET | `/price/<active>` | Цена (если поддерживается) |

### Пример открытия сделки

```bash
curl -X POST http://localhost:8765/buy \
  -H "Content-Type: application/json" \
  -d '{
    "active": "EURUSD_otc",
    "direction": "call",
    "amount": 1,
    "duration": 60
  }'
```

- `direction`: `call` = ВВЕРХ, `put` = ВНИЗ  
- Для OTC-пар обязательно суффикс `_otc`

## Связь с Supabase Edge Function

В секретах Supabase можно добавить:

```
POCKET_SSID=42["auth",{...}]
PYTHON_BOT_URL=http://твой-сервер:8765
```

Тогда `/health` edge-функции будет показывать реальное состояние Python-бота.

## Важные замечания

- **Не используй реальный счёт**, пока не протестируешь на демо.
- SSID = доступ к твоему аккаунту. Никому не передавай.
- Библиотека неофициальная — Pocket Option может менять протокол.
- Сигналы в текущем frontend по-прежнему генерируются в edge-функции (рандом).  
  Чтобы сделать их «умными», нужно писать стратегию поверх цен из WebSocket.

## Альтернатива — чистый скрипт без HTTP

Если нужен просто терминальный бот:

```python
from pocketoptionapi.stable_api import PocketOption
import time

ssid = """42["auth",{"session":"...","isDemo":1,"uid":123,"platform":2}]"""
api = PocketOption(ssid, True)  # True = demo
api.connect()
time.sleep(2)
print("Баланс:", api.get_balance())

# Подписка на цену (если поддерживается версией)
# @api.on_price_update
# def on_price(data):
#     print(data)
```
