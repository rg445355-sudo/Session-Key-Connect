import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const OTC_PAIRS = [
  "EURUSD_otc",
  "GBPUSD_otc",
  "USDJPY_otc",
  "AUDUSD_otc",
  "USDCAD_otc",
  "EURGBP_otc",
  "EURJPY_otc",
  "GBPJPY_otc",
];

const PAIR_PRETTY: Record<string, string> = {
  "EURUSD_otc": "EUR/USD",
  "GBPUSD_otc": "GBP/USD",
  "USDJPY_otc": "USD/JPY",
  "AUDUSD_otc": "AUD/USD",
  "USDCAD_otc": "USD/CAD",
  "EURGBP_otc": "EUR/GBP",
  "EURJPY_otc": "EUR/JPY",
  "GBPJPY_otc": "GBP/JPY",
};

function makePrettyPair(pair: string): string {
  return PAIR_PRETTY[pair] || pair.replace("_otc", "");
}

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function nowMoscowTime(): string {
  return new Date().toLocaleTimeString("ru-RU", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    timeZone: "Europe/Moscow",
  });
}

interface SignalRow {
  id: string;
  pair: string;
  raw_pair: string;
  direction: string;
  confidence: number;
  expiry: string;
  payout: string;
  status: string;
  entry_price: number | null;
  close_price: number | null;
  need_overlap: boolean;
  overlap_direction: string | null;
  message: string;
  is_active: boolean;
  participant_id: string | null;
  created_at: string;
  expires_at: string;
}

function rowToSignal(row: SignalRow) {
  return {
    pair: row.pair,
    direction: row.direction,
    confidence: row.confidence,
    expiry: row.expiry,
    payout: row.payout,
    time: nowMoscowTime(),
    status: row.status,
    entry_price: row.entry_price,
    close_price: row.close_price,
    need_overlap: row.need_overlap,
    overlap_direction: row.overlap_direction,
    message: row.message,
  };
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  const url = new URL(req.url);
  const path = url.pathname.replace(/^\/radik-bot/, "");

  try {
    /* ── GET /signal — get current or new signal ── */
    if (path === "/signal" && req.method === "GET") {
      // Check for pending overlap first
      const { data: overlapRow } = await supabase
        .from("bot_signals")
        .select("*")
        .eq("is_active", true)
        .eq("status", "overlap")
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      if (overlapRow) {
        return new Response(JSON.stringify(rowToSignal(overlapRow as SignalRow)), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Deactivate previous active signals
      await supabase
        .from("bot_signals")
        .update({ is_active: false })
        .eq("is_active", true);

      // Generate a new signal
      const rawPair = pick(OTC_PAIRS);
      const direction = pick(["ВВЕРХ", "ВНИЗ"]);
      const confidence = 88 + Math.floor(Math.random() * 7); // 88-94
      const participantId = url.searchParams.get("participant_id");

      const { data: newRow, error } = await supabase
        .from("bot_signals")
        .insert({
          pair: makePrettyPair(rawPair),
          raw_pair: rawPair,
          direction,
          confidence,
          expiry: "2 мин",
          payout: "92%",
          status: "new",
          message: direction === "ВВЕРХ"
            ? "Импульс вверх: краткосрочный моментум и давление покупателей на OTC. Точка входа по текущей цене, экспирация 2 мин."
            : "Импульс вниз: продавцы доминируют на коротком ТФ. Точка входа по текущей цене, экспирация 2 мин.",
          is_active: true,
          participant_id: participantId,
        })
        .select("*")
        .single();

      if (error) throw error;

      return new Response(JSON.stringify(rowToSignal(newRow as SignalRow)), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    /* ── POST /signal/result — report win/loss, get overlap if lost ── */
    if (path === "/signal/result" && req.method === "POST") {
      const body = await req.json();
      const won: boolean = body.won;
      const entryPrice: number = body.entry_price || 0;
      const closePrice: number = body.close_price || 0;

      // Get current active signal
      const { data: currentRow, error: curErr } = await supabase
        .from("bot_signals")
        .select("*")
        .eq("is_active", true)
        .in("status", ["new", "tracking"])
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      if (curErr) throw curErr;
      if (!currentRow) {
        return new Response(JSON.stringify({ error: "Нет активного сигнала" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const current = currentRow as SignalRow;

      if (won) {
        await supabase
          .from("bot_signals")
          .update({
            status: "won",
            entry_price: entryPrice,
            close_price: closePrice,
            need_overlap: false,
            message: "Сигнал зашёл. Перекрытие не нужно.",
          })
          .eq("id", current.id);

        return new Response(
          JSON.stringify({
            pair: current.pair,
            direction: current.direction,
            confidence: current.confidence,
            expiry: current.expiry,
            payout: current.payout,
            time: nowMoscowTime(),
            status: "won",
            entry_price: entryPrice,
            close_price: closePrice,
            need_overlap: false,
            overlap_direction: null,
            message: "Сигнал зашёл. Перекрытие не нужно.",
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Lost — create overlap signal
      const opposite = current.direction === "ВВЕРХ" ? "ВНИЗ" : "ВВЕРХ";

      await supabase
        .from("bot_signals")
        .update({
          status: "lost",
          entry_price: entryPrice,
          close_price: closePrice,
          need_overlap: true,
          message: "Сигнал проиграл. Жди перекрытие.",
        })
        .eq("id", current.id);

      const { data: overlapRow, error: overlapErr } = await supabase
        .from("bot_signals")
        .insert({
          pair: current.pair,
          raw_pair: current.raw_pair,
          direction: opposite,
          confidence: 90,
          expiry: "2 мин",
          payout: "92%",
          status: "overlap",
          entry_price: closePrice,
          close_price: null,
          need_overlap: true,
          overlap_direction: opposite,
          message: `Сигнал не зашёл. Рекомендуется ПЕРЕКРЫТИЕ в сторону ${opposite} на 2 минуты.`,
          is_active: true,
          participant_id: current.participant_id,
        })
        .select("*")
        .single();

      if (overlapErr) throw overlapErr;

      return new Response(JSON.stringify(rowToSignal(overlapRow as SignalRow)), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    /* ── GET /status — current state ── */
    if (path === "/status" && req.method === "GET") {
      const { data: currentRow } = await supabase
        .from("bot_signals")
        .select("*")
        .eq("is_active", true)
        .in("status", ["new", "tracking"])
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      const { data: overlapRow } = await supabase
        .from("bot_signals")
        .select("*")
        .eq("is_active", true)
        .eq("status", "overlap")
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      return new Response(
        JSON.stringify({
          current: currentRow ? rowToSignal(currentRow as SignalRow) : null,
          overlap: overlapRow ? rowToSignal(overlapRow as SignalRow) : null,
          time: new Date().toISOString(),
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    /* ── GET /health ── */
    if (path === "/health" && req.method === "GET") {
      // SSID хранится в секретах Supabase (POCKET_SSID)
      // Реальное WebSocket-подключение живёт в python-bot/ (см. README)
      const ssid = Deno.env.get("POCKET_SSID") || "";
      const ssidLoaded = ssid.length > 20 && ssid.includes("session");
      const pythonApi = Deno.env.get("PYTHON_BOT_URL"); // например http://localhost:8765

      let pythonStatus: Record<string, unknown> | null = null;
      if (pythonApi) {
        try {
          const r = await fetch(`${pythonApi}/health`, { signal: AbortSignal.timeout(3000) });
          pythonStatus = await r.json();
        } catch {
          pythonStatus = { connected: false, error: "python-bot unreachable" };
        }
      }

      return new Response(
        JSON.stringify({
          status: "ok",
          ssid_loaded: ssidLoaded,
          python_bot: pythonStatus,
          message: ssidLoaded
            ? "SSID найден. Для реального WebSocket запусти python-bot/bot.py"
            : "POCKET_SSID не задан в secrets. Сигналы пока генерируются локально.",
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    /* ── GET /history — recent signals for feed ── */
    if (path === "/history" && req.method === "GET") {
      const limit = parseInt(url.searchParams.get("limit") || "10");
      const { data: rows } = await supabase
        .from("bot_signals")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(limit);

      const history = (rows || []).map((r: SignalRow) => ({
        id: r.id,
        pair: r.pair,
        direction: r.direction,
        confidence: r.confidence,
        expiry: r.expiry,
        status: r.status,
        time: new Date(r.created_at).toLocaleTimeString("ru-RU", {
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
        }),
        message: r.message,
      }));

      return new Response(JSON.stringify({ signals: history }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ error: "Not found" }), {
      status: 404,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message || "Internal error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
