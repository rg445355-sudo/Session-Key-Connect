/*
# Create bot_signals table for RADIK AI BOT signal engine

1. New Tables
- `bot_signals`
  - `id` (uuid, primary key)
  - `pair` (text, pretty pair name like "EUR/USD")
  - `raw_pair` (text, raw pair like "EURUSD_otc")
  - `direction` (text, "ВВЕРХ" or "ВНИЗ")
  - `confidence` (int, 88-94)
  - `expiry` (text, always "2 мин")
  - `payout` (text, e.g. "92%")
  - `status` (text, "new" / "tracking" / "won" / "lost" / "overlap")
  - `entry_price` (float8, nullable)
  - `close_price` (float8, nullable)
  - `need_overlap` (boolean, default false)
  - `overlap_direction` (text, nullable)
  - `message` (text, human-readable status message)
  - `is_active` (boolean, default true — marks the current/active signal)
  - `participant_id` (text, the Pocket Option ID of the user)
  - `created_at` (timestamptz, default now())
  - `expires_at` (timestamptz, created_at + 2 minutes)

2. Security
- Enable RLS on `bot_signals`.
- Allow anon + authenticated CRUD because the app is single-tenant (no sign-in screen, gate is just an ID entry).
*/

CREATE TABLE IF NOT EXISTS bot_signals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pair text NOT NULL,
  raw_pair text NOT NULL,
  direction text NOT NULL,
  confidence int NOT NULL DEFAULT 90,
  expiry text NOT NULL DEFAULT '2 мин',
  payout text NOT NULL DEFAULT '92%',
  status text NOT NULL DEFAULT 'new',
  entry_price float8,
  close_price float8,
  need_overlap boolean NOT NULL DEFAULT false,
  overlap_direction text,
  message text NOT NULL DEFAULT '',
  is_active boolean NOT NULL DEFAULT true,
  participant_id text,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL DEFAULT (now() + interval '2 minutes')
);

ALTER TABLE bot_signals ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_bot_signals" ON bot_signals;
CREATE POLICY "anon_select_bot_signals"
ON bot_signals FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_bot_signals" ON bot_signals;
CREATE POLICY "anon_insert_bot_signals"
ON bot_signals FOR INSERT
TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_bot_signals" ON bot_signals;
CREATE POLICY "anon_update_bot_signals"
ON bot_signals FOR UPDATE
TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_bot_signals" ON bot_signals;
CREATE POLICY "anon_delete_bot_signals"
ON bot_signals FOR DELETE
TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_bot_signals_active ON bot_signals(is_active) WHERE is_active = true;
CREATE INDEX IF NOT EXISTS idx_bot_signals_created_at ON bot_signals(created_at DESC);
