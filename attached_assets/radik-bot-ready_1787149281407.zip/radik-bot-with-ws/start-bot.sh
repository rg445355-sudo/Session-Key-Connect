#!/bin/bash
set -e
cd "$(dirname "$0")"
echo "=== RADIK Pocket Option Bot ==="
if command -v docker >/dev/null 2>&1; then
  echo "Запуск через Docker..."
  docker compose up -d --build
  echo ""
  echo "Логи:  docker compose logs -f pocket-bot"
  echo "Стоп:  docker compose down"
  echo "Health: curl http://localhost:8765/health"
else
  echo "Docker не найден — запускаю напрямую..."
  cd python-bot && ./start.sh
fi
