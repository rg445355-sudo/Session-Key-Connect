# RADIK AI BOT — готово к хостингу

## Что внутри

| Часть | Что это | Где хостить |
|-------|---------|-------------|
| Frontend (React) | UI сигналов | Vercel / Netlify / Cloudflare Pages / любой static host |
| Supabase Edge Function | Генерация сигналов + API | Уже на Supabase |
| **python-bot** | WebSocket → Pocket Option | VPS / Railway / Render / Docker |

---

## 1. Python-бот (WebSocket) — Docker

На любом VPS с Docker:

```bash
# склонируй/залей проект
cd radik-bot-with-ws

# проверь SSID в python-bot/.env
cat python-bot/.env

# запуск
docker compose up -d --build

# логи
docker compose logs -f pocket-bot
```

Проверка:
```bash
curl http://localhost:8765/health
```

Ответ при успехе:
```json
{"status":"ok","connected":true,"balance":1234.56,"uid":92535291,...}
```

### Без Docker

```bash
cd python-bot
pip install -r requirements.txt
python bot.py
```

### Публичный доступ

- Открой порт **8765** в firewall
- Или поставь nginx/caddy reverse proxy + HTTPS
- В secrets Supabase добавь: `PYTHON_BOT_URL=https://твой-домен:8765`

---

## 2. Frontend

```bash
cd radik-bot-with-ws
npm install
npm run build
# папка dist/ → залей на Vercel / Netlify / любой static host
```

Переменные окружения (уже в `.env`):
```
VITE_SUPABASE_URL=...
VITE_SUPABASE_ANON_KEY=...
```

---

## 3. Supabase

Edge Function `radik-bot` уже в проекте.  
Задеплой:

```bash
supabase functions deploy radik-bot
```

Secrets (в Dashboard → Edge Functions → Secrets):
```
POCKET_SSID=42["auth",{"session":"AS3mB9vRAAp_kSvd7","isDemo":1,"uid":92535291,"platform":2}]
PYTHON_BOT_URL=http://IP-твоего-VPS:8765
```

---

## 4. Текущий SSID

```
session : AS3mB9vRAAp_kSvd7
uid     : 92535291
isDemo  : 1 (демо)
```

Если SSID протухнет — получи новый из браузера (F12 → Network → WS → `42["auth",...`) и обнови `.env`, затем:

```bash
docker compose up -d --build
```

---

## Быстрый чеклист перед хостингом

- [ ] `python-bot/.env` содержит актуальный SSID
- [ ] `docker compose up -d --build` — бот зелёный в логах
- [ ] `curl /health` → `"connected": true`
- [ ] Frontend `npm run build` → залит
- [ ] Supabase function задеплоена
- [ ] (опционально) PYTHON_BOT_URL указывает на твой VPS

Готово. Бот слушает `:8765` и держит WebSocket к Pocket Option.
